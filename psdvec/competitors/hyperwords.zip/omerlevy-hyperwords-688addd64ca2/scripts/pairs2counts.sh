#!/bin/sh
sort -T . $1 | uniq -c